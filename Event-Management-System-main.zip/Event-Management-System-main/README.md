# Event-Management-System


## Installation

```
All Installions are added in corresponding folders 

1. Install Dart

2. Install Java

3. Install Android Studio

4. Install Flutter
```


# How to run

```
$ cd EventManager

$ flutter run
```
