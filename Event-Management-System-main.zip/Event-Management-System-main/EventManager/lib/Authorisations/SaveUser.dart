class SaveUser {
  String userID, email, displayName, phoneNumber;

  SaveUser(
      {this.userID,
      this.displayName,
      this.email,
      this.phoneNumber}); // constructor

}
