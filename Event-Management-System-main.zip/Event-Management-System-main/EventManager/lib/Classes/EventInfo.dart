class EventInfo {
  // ignore: non_constant_identifier_names
  String event_id,event_name,place,description,price,short_description;
  // ignore: non_constant_identifier_names
  DateTime start_date_time,end_date_time,register_start_date_time,register_end_date_time;

  String imageURL = "https://parsec.iitdh.ac.in/images/logos/logo-about.jpg";


  
}

