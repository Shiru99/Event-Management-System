class GuestInfo{
   // ignore: non_constant_identifier_names
   String guest_id,guest_name,description,guest_cno,guest_email;

  String imageURL = "https://parsec.iitdh.ac.in/images/logos/logo-about.jpg";

}
