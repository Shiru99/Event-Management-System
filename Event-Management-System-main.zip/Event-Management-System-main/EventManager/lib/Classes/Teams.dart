class Teams {
  // ignore: non_constant_identifier_names
  String group_id,group_name,score,review;
  // ignore: non_constant_identifier_names
  List<String> participant_id = [];
  // ignore: non_constant_identifier_names
  List<String> participant_name = [];
  // ignore: non_constant_identifier_names
  List<String> participant_cno = [];
  // ignore: non_constant_identifier_names
  List<String> participant_email = [];
}