class SponsorInfo {
  // ignore: non_constant_identifier_names
  String sponsor_id,sponsor_name,sponsor_phone,sponsor_category,price,sponsor_link;  
}